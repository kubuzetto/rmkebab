# rmkebab

https://addons.mozilla.org/en-US/firefox/addon/remove-kebab/

Adds the ability to 'block' some restaurants in http://yemeksepeti.com. Don't let the kebab clutter your menu!

TODO
----

- 'Options' page
- Only list the restaurants that are being blocked in the page currently; instead of all blacklisted
- Multi-language support

